./bin/ldecod input/test.264 golden/test_dec.yuv


